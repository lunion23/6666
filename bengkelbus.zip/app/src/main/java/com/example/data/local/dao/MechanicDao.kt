package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.MechanicEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MechanicDao {
    @Query("SELECT * FROM mechanics ORDER BY name ASC")
    fun getAllMechanics(): Flow<List<MechanicEntity>>

    @Query("SELECT * FROM mechanics WHERE status = 'ACTIVE' ORDER BY name ASC")
    fun getActiveMechanics(): Flow<List<MechanicEntity>>

    @Query("SELECT * FROM mechanics WHERE isSyncNeeded = 1")
    suspend fun getUnsyncedMechanics(): List<MechanicEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMechanic(mechanic: MechanicEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMechanics(mechanics: List<MechanicEntity>)

    @Update
    suspend fun updateMechanic(mechanic: MechanicEntity)

    @Query("UPDATE mechanics SET isSyncNeeded = 0 WHERE id IN (:ids)")
    suspend fun markAsSynced(ids: List<String>)

    @Query("DELETE FROM mechanics WHERE id = :id")
    suspend fun deleteMechanic(id: String)
}
