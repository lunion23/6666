package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.BusEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BusDao {
    @Query("SELECT * FROM buses ORDER BY fleetNumber ASC")
    fun getAllBuses(): Flow<List<BusEntity>>

    @Query("SELECT * FROM buses WHERE id = :id LIMIT 1")
    suspend fun getBusById(id: String): BusEntity?

    @Query("SELECT * FROM buses WHERE isSyncNeeded = 1")
    suspend fun getUnsyncedBuses(): List<BusEntity>

    @Query("SELECT COUNT(*) FROM buses")
    fun getBusCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM buses WHERE status = 'READY'")
    fun getReadyBusCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM buses WHERE status = 'MAINTENANCE'")
    fun getMaintenanceBusCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBus(bus: BusEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBuses(buses: List<BusEntity>)

    @Update
    suspend fun updateBus(bus: BusEntity)

    @Query("UPDATE buses SET isSyncNeeded = 0 WHERE id IN (:ids)")
    suspend fun markAsSynced(ids: List<String>)

    @Query("DELETE FROM buses WHERE id = :id")
    suspend fun deleteBus(id: String)
}
