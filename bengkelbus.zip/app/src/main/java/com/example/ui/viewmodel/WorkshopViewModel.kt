package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.BusEntity
import com.example.data.local.entity.MechanicEntity
import com.example.data.local.entity.ServiceOrderEntity
import com.example.data.local.entity.SparepartEntity
import com.example.data.model.SyncState
import com.example.data.model.SyncStats
import com.example.data.repository.WorkshopRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class WorkshopViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = WorkshopRepository(application.applicationContext)

    val buses: StateFlow<List<BusEntity>> = repository.getAllBuses()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val busCount: StateFlow<Int> = repository.getBusCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val readyBusCount: StateFlow<Int> = repository.getReadyBusCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val maintenanceBusCount: StateFlow<Int> = repository.getMaintenanceBusCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val spareparts: StateFlow<List<SparepartEntity>> = repository.getAllSpareparts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockSpareparts: StateFlow<List<SparepartEntity>> = repository.getLowStockSpareparts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockCount: StateFlow<Int> = repository.getLowStockCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val serviceOrders: StateFlow<List<ServiceOrderEntity>> = repository.getAllServiceOrders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeServiceOrders: StateFlow<List<ServiceOrderEntity>> = repository.getActiveServiceOrders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeOrdersCount: StateFlow<Int> = repository.getActiveOrdersCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val mechanics: StateFlow<List<MechanicEntity>> = repository.getAllMechanics()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Sync state & network state
    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private val _syncStats = MutableStateFlow(SyncStats())
    val syncStats: StateFlow<SyncStats> = _syncStats.asStateFlow()

    private val _isOnline = MutableStateFlow(false)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    init {
        checkNetwork()
        refreshSyncStats()
    }

    fun checkNetwork() {
        _isOnline.value = repository.isNetworkAvailable()
    }

    fun refreshSyncStats() {
        viewModelScope.launch {
            _syncStats.value = repository.getSyncStats()
        }
    }

    /**
     * Trigger manual or automatic Cloud Sync to Firestore.
     * Respects Spark Plan limits (Delta sync & batch updates).
     */
    fun performCloudSync() {
        checkNetwork()
        if (!_isOnline.value) {
            _syncState.value = SyncState.Error(
                "Tidak ada koneksi internet. Semua perubahan tersimpan aman di database Room lokal bengkel."
            )
            return
        }

        viewModelScope.launch {
            _syncState.value = SyncState.Syncing("Menghubungkan ke Cloud Firestore (Spark Plan)...")
            val result = repository.syncAll()
            result.onSuccess { (uploaded, downloaded) ->
                val summary = "Sinkronisasi Berhasil: $uploaded data diunggah ke cloud, $downloaded pembaruan diunduh."
                _syncState.value = SyncState.Success(summary)
                refreshSyncStats()
            }.onFailure { ex ->
                val err = ex.localizedMessage ?: "Gagal sinkronisasi data"
                _syncState.value = SyncState.Error(
                    if (err.contains("google-services") || err.contains("default FirebaseApp") || err.contains("API key")) {
                        "Firebase belum terhubung: Gunakan google-services.json asli Anda dari Firebase Console. Data lokal tetap aman 100% di Room!"
                    } else {
                        "Sinkronisasi ditunda: $err. Data tetap aman di Room lokal."
                    }
                )
                refreshSyncStats()
            }
        }
    }

    fun dismissSyncBanner() {
        _syncState.value = SyncState.Idle
    }

    // Bus operations
    fun addOrUpdateBus(
        id: String,
        plateNumber: String,
        fleetNumber: String,
        busModel: String,
        capacity: Int,
        mileageKm: Int,
        status: String,
        notes: String
    ) {
        viewModelScope.launch {
            val entity = BusEntity(
                id = if (id.isBlank()) "BUS-${System.currentTimeMillis().toString().takeLast(4)}" else id,
                plateNumber = plateNumber.trim().uppercase(),
                fleetNumber = fleetNumber.trim().uppercase(),
                busModel = busModel.trim(),
                capacity = capacity,
                mileageKm = mileageKm,
                status = status,
                notes = notes.trim()
            )
            repository.saveBus(entity)
            refreshSyncStats()
        }
    }

    fun deleteBus(busId: String) {
        viewModelScope.launch {
            repository.deleteBus(busId)
            refreshSyncStats()
        }
    }

    // Sparepart operations
    fun addOrUpdateSparepart(
        id: String,
        name: String,
        category: String,
        stockQty: Int,
        minLimit: Int,
        unit: String,
        unitPrice: Double,
        rackLocation: String,
        barcode: String
    ) {
        viewModelScope.launch {
            val entity = SparepartEntity(
                id = if (id.isBlank()) "PRT-${System.currentTimeMillis().toString().takeLast(5)}" else id,
                partName = name.trim(),
                category = category,
                stockQty = stockQty,
                minStockLimit = minLimit,
                unit = unit,
                unitPrice = unitPrice,
                rackLocation = rackLocation.trim(),
                barcode = barcode.trim()
            )
            repository.saveSparepart(entity)
            refreshSyncStats()
        }
    }

    fun deleteSparepart(partId: String) {
        viewModelScope.launch {
            repository.deleteSparepart(partId)
            refreshSyncStats()
        }
    }

    // Service Order (SPK) operations
    fun createServiceOrder(
        bus: BusEntity,
        mechanic: MechanicEntity?,
        complaint: String,
        laborCost: Double
    ) {
        viewModelScope.launch {
            val orderId = "SPK-${System.currentTimeMillis().toString().takeLast(6)}"
            val entity = ServiceOrderEntity(
                id = orderId,
                busId = bus.id,
                busPlate = "${bus.fleetNumber} (${bus.plateNumber})",
                mechanicId = mechanic?.id ?: "",
                mechanicName = mechanic?.name ?: "Mekanik Umum",
                complaint = complaint.trim(),
                status = "ON_PROGRESS",
                entryDate = System.currentTimeMillis(),
                laborCost = laborCost,
                totalPartsCost = 0.0
            )
            repository.saveServiceOrder(entity)

            // Update bus status to MAINTENANCE
            repository.saveBus(bus.copy(status = "MAINTENANCE"))
            refreshSyncStats()
        }
    }

    fun completeServiceOrder(orderId: String, finalNotes: String) {
        viewModelScope.launch {
            repository.completeServiceOrder(orderId, finalNotes)
            refreshSyncStats()
        }
    }

    fun addPartToOrder(orderId: String, partId: String, quantity: Int) {
        viewModelScope.launch {
            repository.addPartUsage(orderId, partId, quantity)
            refreshSyncStats()
        }
    }

    fun getUsagesForOrder(orderId: String) = repository.getUsagesByOrderId(orderId)

    // Mechanic operations
    fun addMechanic(name: String, phone: String, specialty: String) {
        viewModelScope.launch {
            val entity = MechanicEntity(
                id = "MEC-${System.currentTimeMillis().toString().takeLast(4)}",
                name = name.trim(),
                phone = phone.trim(),
                specialty = specialty
            )
            repository.saveMechanic(entity)
            refreshSyncStats()
        }
    }
}
