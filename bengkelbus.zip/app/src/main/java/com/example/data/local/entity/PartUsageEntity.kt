package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "part_usages",
    indices = [
        Index(value = ["serviceOrderId"]),
        Index(value = ["sparepartId"])
    ]
)
data class PartUsageEntity(
    @PrimaryKey
    val id: String, // e.g. "USE-1234"
    val serviceOrderId: String, // foreign key relation
    val sparepartId: String,
    val partName: String,
    val quantity: Int = 1,
    val unitPrice: Double = 0.0,
    val subtotal: Double = unitPrice * quantity,
    val updatedAt: Long = System.currentTimeMillis(),
    val isSyncNeeded: Boolean = true
) {
    fun toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "serviceOrderId" to serviceOrderId,
        "sparepartId" to sparepartId,
        "partName" to partName,
        "quantity" to quantity,
        "unitPrice" to unitPrice,
        "subtotal" to subtotal,
        "updatedAt" to updatedAt
    )

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): PartUsageEntity = PartUsageEntity(
            id = (map["id"] as? String) ?: "",
            serviceOrderId = (map["serviceOrderId"] as? String) ?: "",
            sparepartId = (map["sparepartId"] as? String) ?: "",
            partName = (map["partName"] as? String) ?: "",
            quantity = (map["quantity"] as? Number)?.toInt() ?: 1,
            unitPrice = (map["unitPrice"] as? Number)?.toDouble() ?: 0.0,
            subtotal = (map["subtotal"] as? Number)?.toDouble() ?: 0.0,
            updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
            isSyncNeeded = false
        )
    }
}
