package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.ServiceOrderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ServiceOrderDao {
    @Query("SELECT * FROM service_orders ORDER BY entryDate DESC")
    fun getAllServiceOrders(): Flow<List<ServiceOrderEntity>>

    @Query("SELECT * FROM service_orders WHERE id = :id LIMIT 1")
    suspend fun getServiceOrderById(id: String): ServiceOrderEntity?

    @Query("SELECT * FROM service_orders WHERE status IN ('PENDING', 'ON_PROGRESS') ORDER BY entryDate DESC")
    fun getActiveServiceOrders(): Flow<List<ServiceOrderEntity>>

    @Query("SELECT COUNT(*) FROM service_orders WHERE status IN ('PENDING', 'ON_PROGRESS')")
    fun getActiveServiceOrdersCount(): Flow<Int>

    @Query("SELECT * FROM service_orders WHERE isSyncNeeded = 1")
    suspend fun getUnsyncedServiceOrders(): List<ServiceOrderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServiceOrder(order: ServiceOrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServiceOrders(orders: List<ServiceOrderEntity>)

    @Update
    suspend fun updateServiceOrder(order: ServiceOrderEntity)

    @Query("UPDATE service_orders SET isSyncNeeded = 0 WHERE id IN (:ids)")
    suspend fun markAsSynced(ids: List<String>)

    @Query("DELETE FROM service_orders WHERE id = :id")
    suspend fun deleteServiceOrder(id: String)
}
