package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.BusDao
import com.example.data.local.dao.MechanicDao
import com.example.data.local.dao.PartUsageDao
import com.example.data.local.dao.ServiceOrderDao
import com.example.data.local.dao.SparepartDao
import com.example.data.local.entity.BusEntity
import com.example.data.local.entity.MechanicEntity
import com.example.data.local.entity.PartUsageEntity
import com.example.data.local.entity.ServiceOrderEntity
import com.example.data.local.entity.SparepartEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        BusEntity::class,
        SparepartEntity::class,
        ServiceOrderEntity::class,
        PartUsageEntity::class,
        MechanicEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun busDao(): BusDao
    abstract fun sparepartDao(): SparepartDao
    abstract fun serviceOrderDao(): ServiceOrderDao
    abstract fun partUsageDao(): PartUsageDao
    abstract fun mechanicDao(): MechanicDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "bengkel_bus.db"
                )
                    .addCallback(DatabaseCallback())
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }

            private suspend fun populateInitialData(db: AppDatabase) {
                val bus1 = BusEntity(
                    id = "BUS-001",
                    plateNumber = "B 7201 VGA",
                    fleetNumber = "ARM-01",
                    busModel = "Jetbus 3+ SHD (Scania K360IB)",
                    capacity = 48,
                    mileageKm = 142500,
                    status = "READY",
                    notes = "Armada Executive Ekstra Aman",
                    updatedAt = System.currentTimeMillis()
                )
                val bus2 = BusEntity(
                    id = "BUS-002",
                    plateNumber = "B 7202 VGA",
                    fleetNumber = "ARM-02",
                    busModel = "Legacy SR2 XHD Prime (Hino RK8)",
                    capacity = 50,
                    mileageKm = 98400,
                    status = "MAINTENANCE",
                    notes = "Jadwal Servis Berkala & Rem",
                    updatedAt = System.currentTimeMillis()
                )
                val bus3 = BusEntity(
                    id = "BUS-003",
                    plateNumber = "B 7203 VGA",
                    fleetNumber = "ARM-03",
                    busModel = "Avante H8 (Mercedes-Benz OH 1626)",
                    capacity = 44,
                    mileageKm = 63100,
                    status = "READY",
                    notes = "Kondisi Prima, Suspensi Udara Normal",
                    updatedAt = System.currentTimeMillis()
                )
                db.busDao().insertBuses(listOf(bus1, bus2, bus3))

                val part1 = SparepartEntity(
                    id = "PRT-FLT-001",
                    partName = "Filter Oli Sakura C-5811",
                    category = "Mesin",
                    stockQty = 14,
                    minStockLimit = 5,
                    unit = "Pcs",
                    unitPrice = 125000.0,
                    rackLocation = "Rak A-01",
                    barcode = "8992812001",
                    updatedAt = System.currentTimeMillis()
                )
                val part2 = SparepartEntity(
                    id = "PRT-BRK-002",
                    partName = "Brake Shoe / Kampas Rem Tromol Hino",
                    category = "Pengereman",
                    stockQty = 3, // Low stock
                    minStockLimit = 6,
                    unit = "Set",
                    unitPrice = 450000.0,
                    rackLocation = "Rak B-03",
                    barcode = "8992812002",
                    updatedAt = System.currentTimeMillis()
                )
                val part3 = SparepartEntity(
                    id = "PRT-OIL-003",
                    partName = "Oli Mesin Diesel Meditran SX 15W-40",
                    category = "Oli & Fluida",
                    stockQty = 45,
                    minStockLimit = 20,
                    unit = "Liter",
                    unitPrice = 58000.0,
                    rackLocation = "Drum D-01",
                    barcode = "8992812003",
                    updatedAt = System.currentTimeMillis()
                )
                val part4 = SparepartEntity(
                    id = "PRT-AIR-004",
                    partName = "Air Filter Donalson P181050",
                    category = "Mesin",
                    stockQty = 2, // Low stock
                    minStockLimit = 4,
                    unit = "Pcs",
                    unitPrice = 320000.0,
                    rackLocation = "Rak A-04",
                    barcode = "8992812004",
                    updatedAt = System.currentTimeMillis()
                )
                db.sparepartDao().insertSpareparts(listOf(part1, part2, part3, part4))

                val mech1 = MechanicEntity(
                    id = "MEC-01",
                    name = "Budi Santoso",
                    phone = "081234567890",
                    specialty = "Mesin Diesel & Transmisi",
                    status = "ACTIVE",
                    updatedAt = System.currentTimeMillis()
                )
                val mech2 = MechanicEntity(
                    id = "MEC-02",
                    name = "Agus Prasetyo",
                    phone = "082345678901",
                    specialty = "Pneumatik & Kaki-kaki Rem",
                    status = "ACTIVE",
                    updatedAt = System.currentTimeMillis()
                )
                val mech3 = MechanicEntity(
                    id = "MEC-03",
                    name = "Deni Hendrawan",
                    phone = "083456789012",
                    specialty = "Kelistrikan & AC Bus",
                    status = "ACTIVE",
                    updatedAt = System.currentTimeMillis()
                )
                db.mechanicDao().insertMechanics(listOf(mech1, mech2, mech3))

                val order1 = ServiceOrderEntity(
                    id = "SPK-2026-001",
                    busId = "BUS-002",
                    busPlate = "B 7202 VGA",
                    mechanicId = "MEC-02",
                    mechanicName = "Agus Prasetyo",
                    complaint = "Pedal rem terasa dalam dan bergetar saat deselerasi",
                    status = "ON_PROGRESS",
                    entryDate = System.currentTimeMillis() - 86400000L,
                    laborCost = 150000.0,
                    totalPartsCost = 450000.0,
                    mechanicNotes = "Sedang proses penggantian kampas rem roda belakang",
                    updatedAt = System.currentTimeMillis()
                )
                db.serviceOrderDao().insertServiceOrder(order1)

                val usage1 = PartUsageEntity(
                    id = "USG-001",
                    serviceOrderId = "SPK-2026-001",
                    sparepartId = "PRT-BRK-002",
                    partName = "Brake Shoe / Kampas Rem Tromol Hino",
                    quantity = 1,
                    unitPrice = 450000.0,
                    subtotal = 450000.0,
                    updatedAt = System.currentTimeMillis()
                )
                db.partUsageDao().insertPartUsage(usage1)
            }
        }
    }
}
