package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.BusEntity
import com.example.data.local.entity.MechanicEntity
import com.example.data.local.entity.PartUsageEntity
import com.example.data.local.entity.ServiceOrderEntity
import com.example.data.local.entity.SparepartEntity
import com.example.ui.components.formatDateTime
import com.example.ui.components.formatRupiah
import com.example.ui.viewmodel.WorkshopViewModel

@Composable
fun ServiceScreen(
    viewModel: WorkshopViewModel,
    modifier: Modifier = Modifier
) {
    val serviceOrders by viewModel.serviceOrders.collectAsState()
    val buses by viewModel.buses.collectAsState()
    val mechanics by viewModel.mechanics.collectAsState()
    val spareparts by viewModel.spareparts.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }
    var orderForPartUsage by remember { mutableStateOf<ServiceOrderEntity?>(null) }
    var orderToComplete by remember { mutableStateOf<ServiceOrderEntity?>(null) }
    var selectedFilter by remember { mutableStateOf("ALL") }

    val filteredOrders = remember(serviceOrders, selectedFilter) {
        when (selectedFilter) {
            "ACTIVE" -> serviceOrders.filter { it.status == "ON_PROGRESS" || it.status == "PENDING" }
            "COMPLETED" -> serviceOrders.filter { it.status == "COMPLETED" }
            else -> serviceOrders
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                modifier = Modifier.testTag("fab_create_spk"),
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Buat SPK Baru")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Surat Perintah Kerja (SPK)",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Kelola perbaikan armada, alokasi mekanik & pemakaian sparepart",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = selectedFilter == "ALL",
                    onClick = { selectedFilter = "ALL" },
                    label = { Text("Semua (${serviceOrders.size})") }
                )
                FilterChip(
                    selected = selectedFilter == "ACTIVE",
                    onClick = { selectedFilter = "ACTIVE" },
                    label = { Text("Aktif (${serviceOrders.count { it.status != "COMPLETED" }})") }
                )
                FilterChip(
                    selected = selectedFilter == "COMPLETED",
                    onClick = { selectedFilter = "COMPLETED" },
                    label = { Text("Selesai (${serviceOrders.count { it.status == "COMPLETED" }})") }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredOrders.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Belum ada SPK pada kategori ini.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(filteredOrders, key = { it.id }) { order ->
                        val usagesFlow = remember(order.id) { viewModel.getUsagesForOrder(order.id) }
                        val usages by usagesFlow.collectAsState(initial = emptyList())

                        ServiceOrderCard(
                            order = order,
                            usages = usages,
                            onAddPart = { orderForPartUsage = order },
                            onComplete = { orderToComplete = order }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(72.dp))
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateServiceOrderDialog(
            buses = buses,
            mechanics = mechanics,
            onDismiss = { showCreateDialog = false },
            onCreate = { bus, mechanic, complaint, laborCost ->
                viewModel.createServiceOrder(bus, mechanic, complaint, laborCost)
                showCreateDialog = false
            }
        )
    }

    orderForPartUsage?.let { order ->
        AddPartUsageDialog(
            order = order,
            spareparts = spareparts,
            onDismiss = { orderForPartUsage = null },
            onAdd = { partId, qty ->
                viewModel.addPartToOrder(order.id, partId, qty)
                orderForPartUsage = null
            }
        )
    }

    orderToComplete?.let { order ->
        CompleteOrderDialog(
            order = order,
            onDismiss = { orderToComplete = null },
            onConfirm = { notes ->
                viewModel.completeServiceOrder(order.id, notes)
                orderToComplete = null
            }
        )
    }
}

@Composable
fun ServiceOrderCard(
    order: ServiceOrderEntity,
    usages: List<PartUsageEntity>,
    onAddPart: () -> Unit,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isCompleted = order.status == "COMPLETED"
    val statusBg = if (isCompleted) Color(0xFFE8F5E9) else Color(0xFFFFF3E0)
    val statusColor = if (isCompleted) Color(0xFF2E7D32) else Color(0xFFE65100)

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = order.id,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = if (order.isSyncNeeded) Icons.Default.CloudQueue else Icons.Default.CloudDone,
                        contentDescription = if (order.isSyncNeeded) "Perlu Sync" else "Tersinkron",
                        tint = if (order.isSyncNeeded) Color(0xFFE65100) else Color(0xFF2E7D32),
                        modifier = Modifier.padding(2.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = statusBg
                ) {
                    Text(
                        text = if (isCompleted) "SELESAI" else "DALAM PROSES",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Armada: ${order.busPlate}",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "Keluhan: ${order.complaint}",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "Teknisi: ${order.mechanicName} • Masuk: ${formatDateTime(order.entryDate)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Parts used list
            if (usages.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Sparepart Digunakan:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                usages.forEach { usage ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "• ${usage.partName} (${usage.quantity}x)",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = formatRupiah(usage.subtotal),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(6.dp))

            // Total Cost calculation
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Total Biaya (Jasa + Part):",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = formatRupiah(order.totalCost),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (!isCompleted) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onAddPart,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(Icons.Default.Inventory, contentDescription = "Tambah Part", modifier = Modifier.padding(end = 4.dp))
                        Text("Pasang Part")
                    }
                    Button(
                        onClick = onComplete,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        Icon(Icons.Default.Check, contentDescription = "Selesai", modifier = Modifier.padding(end = 4.dp))
                        Text("Selesaikan")
                    }
                }
            } else if (order.mechanicNotes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Catatan Teknisi: ${order.mechanicNotes}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateServiceOrderDialog(
    buses: List<BusEntity>,
    mechanics: List<MechanicEntity>,
    onDismiss: () -> Unit,
    onCreate: (bus: BusEntity, mechanic: MechanicEntity?, complaint: String, laborCost: Double) -> Unit
) {
    var selectedBus by remember { mutableStateOf(buses.firstOrNull()) }
    var selectedMechanic by remember { mutableStateOf(mechanics.firstOrNull()) }
    var complaint by remember { mutableStateOf("") }
    var laborCostText by remember { mutableStateOf("150000") }

    var busDropdownExpanded by remember { mutableStateOf(false) }
    var mechDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Buat SPK Baru") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Bus selector
                ExposedDropdownMenuBox(
                    expanded = busDropdownExpanded,
                    onExpandedChange = { busDropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedBus?.let { "${it.fleetNumber} - ${it.plateNumber}" } ?: "Pilih Bus",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Pilih Armada Bus") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = busDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = busDropdownExpanded,
                        onDismissRequest = { busDropdownExpanded = false }
                    ) {
                        buses.forEach { bus ->
                            DropdownMenuItem(
                                text = { Text("${bus.fleetNumber} - ${bus.plateNumber} (${bus.status})") },
                                onClick = {
                                    selectedBus = bus
                                    busDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Mechanic selector
                ExposedDropdownMenuBox(
                    expanded = mechDropdownExpanded,
                    onExpandedChange = { mechDropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedMechanic?.name ?: "Pilih Mekanik",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Mekanik Bertugas") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = mechDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = mechDropdownExpanded,
                        onDismissRequest = { mechDropdownExpanded = false }
                    ) {
                        mechanics.forEach { mech ->
                            DropdownMenuItem(
                                text = { Text("${mech.name} (${mech.specialty})") },
                                onClick = {
                                    selectedMechanic = mech
                                    mechDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = complaint,
                    onValueChange = { complaint = it },
                    label = { Text("Keluhan / Kerusakan / Instruksi") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = laborCostText,
                    onValueChange = { laborCostText = it },
                    label = { Text("Estimasi Biaya Jasa Mekanik (Rp)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    selectedBus?.let { bus ->
                        if (complaint.isNotBlank()) {
                            onCreate(bus, selectedMechanic, complaint, laborCostText.toDoubleOrNull() ?: 0.0)
                        }
                    }
                },
                enabled = selectedBus != null && complaint.isNotBlank()
            ) {
                Text("Buat SPK")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPartUsageDialog(
    order: ServiceOrderEntity,
    spareparts: List<SparepartEntity>,
    onDismiss: () -> Unit,
    onAdd: (partId: String, qty: Int) -> Unit
) {
    var selectedPart by remember { mutableStateOf(spareparts.firstOrNull()) }
    var qtyText by remember { mutableStateOf("1") }
    var dropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pasang Sparepart ke ${order.id}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ExposedDropdownMenuBox(
                    expanded = dropdownExpanded,
                    onExpandedChange = { dropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedPart?.let { "${it.partName} (Stok: ${it.stockQty} ${it.unit})" } ?: "Pilih Part",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Sparepart dari Gudang") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false }
                    ) {
                        spareparts.forEach { part ->
                            DropdownMenuItem(
                                text = { Text("${part.partName} - Sisa: ${part.stockQty} ${part.unit} (${formatRupiah(part.unitPrice)})") },
                                onClick = {
                                    selectedPart = part
                                    dropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = qtyText,
                    onValueChange = { qtyText = it },
                    label = { Text("Jumlah / Kuantitas") },
                    modifier = Modifier.fillMaxWidth()
                )

                selectedPart?.let { part ->
                    val qty = qtyText.toIntOrNull() ?: 1
                    val subtotal = part.unitPrice * qty
                    Text(
                        text = "Subtotal: ${formatRupiah(subtotal)} (Stok akan otomatis berkurang di Room)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    selectedPart?.let { part ->
                        val qty = qtyText.toIntOrNull() ?: 1
                        if (qty > 0) {
                            onAdd(part.id, qty)
                        }
                    }
                },
                enabled = selectedPart != null && (qtyText.toIntOrNull() ?: 0) > 0
            ) {
                Text("Gunakan Part")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
fun CompleteOrderDialog(
    order: ServiceOrderEntity,
    onDismiss: () -> Unit,
    onConfirm: (notes: String) -> Unit
) {
    var finalNotes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Selesaikan SPK ${order.id}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Armada ${order.busPlate} akan diubah statusnya menjadi SIAP JALAN.",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = finalNotes,
                    onValueChange = { finalNotes = it },
                    label = { Text("Catatan Akhir Teknisi (opsional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(finalNotes) }
            ) {
                Text("Konfirmasi Selesai")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
