package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.SparepartEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SparepartDao {
    @Query("SELECT * FROM spareparts ORDER BY partName ASC")
    fun getAllSpareparts(): Flow<List<SparepartEntity>>

    @Query("SELECT * FROM spareparts WHERE id = :id LIMIT 1")
    suspend fun getSparepartById(id: String): SparepartEntity?

    @Query("SELECT * FROM spareparts WHERE stockQty <= minStockLimit")
    fun getLowStockSpareparts(): Flow<List<SparepartEntity>>

    @Query("SELECT COUNT(*) FROM spareparts WHERE stockQty <= minStockLimit")
    fun getLowStockCount(): Flow<Int>

    @Query("SELECT * FROM spareparts WHERE isSyncNeeded = 1")
    suspend fun getUnsyncedSpareparts(): List<SparepartEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSparepart(sparepart: SparepartEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSpareparts(spareparts: List<SparepartEntity>)

    @Update
    suspend fun updateSparepart(sparepart: SparepartEntity)

    @Query("UPDATE spareparts SET stockQty = stockQty - :usedQty, updatedAt = :updatedAt, isSyncNeeded = 1 WHERE id = :partId")
    suspend fun deductStock(partId: String, usedQty: Int, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE spareparts SET isSyncNeeded = 0 WHERE id IN (:ids)")
    suspend fun markAsSynced(ids: List<String>)

    @Query("DELETE FROM spareparts WHERE id = :id")
    suspend fun deleteSparepart(id: String)
}
