package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.SyncMessageBanner
import com.example.ui.components.SyncStatusHeader
import com.example.ui.screens.BusScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.ReportsAndMechanicsScreen
import com.example.ui.screens.ServiceScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.WorkshopViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                BengkelBusApp()
            }
        }
    }
}

@Composable
fun BengkelBusApp(
    viewModel: WorkshopViewModel = viewModel()
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val isOnline by viewModel.isOnline.collectAsState()
    val syncStats by viewModel.syncStats.collectAsState()
    val syncState by viewModel.syncState.collectAsState()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("bengkel_bus_scaffold"),
        topBar = {
            Column {
                SyncStatusHeader(
                    isOnline = isOnline,
                    syncStats = syncStats,
                    syncState = syncState,
                    onSyncClick = { viewModel.performCloudSync() }
                )
                SyncMessageBanner(
                    syncState = syncState,
                    onDismiss = { viewModel.dismissSyncBanner() }
                )
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                    label = { Text("Dashboard") },
                    modifier = Modifier.testTag("nav_dashboard")
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.DirectionsBus, contentDescription = "Armada") },
                    label = { Text("Armada") },
                    modifier = Modifier.testTag("nav_armada")
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Build, contentDescription = "SPK") },
                    label = { Text("SPK") },
                    modifier = Modifier.testTag("nav_spk")
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Inventory2, contentDescription = "Part") },
                    label = { Text("Part") },
                    modifier = Modifier.testTag("nav_part")
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Icon(Icons.Default.CloudSync, contentDescription = "Cloud & Tim") },
                    label = { Text("Cloud") },
                    modifier = Modifier.testTag("nav_cloud")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToBuses = { selectedTab = 1 },
                    onNavigateToServices = { selectedTab = 2 },
                    onNavigateToInventory = { selectedTab = 3 }
                )
                1 -> BusScreen(viewModel = viewModel)
                2 -> ServiceScreen(viewModel = viewModel)
                3 -> InventoryScreen(viewModel = viewModel)
                4 -> ReportsAndMechanicsScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

