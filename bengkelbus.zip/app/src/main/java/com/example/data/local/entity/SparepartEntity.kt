package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "spareparts")
data class SparepartEntity(
    @PrimaryKey
    val id: String, // SKU / Part Code or UUID, e.g. "PRT-FLT-001"
    val partName: String, // e.g. "Filter Oli Sakura C-5811"
    val category: String, // "Mesin", "Pengereman", "Kelistrikan", "Suspensi", "AC"
    val stockQty: Int = 0,
    val minStockLimit: Int = 5,
    val unit: String = "Pcs", // "Pcs", "Liter", "Set", "Box"
    val unitPrice: Double = 0.0,
    val rackLocation: String = "Rak A-01",
    val barcode: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
    val isSyncNeeded: Boolean = true
) {
    val isLowStock: Boolean get() = stockQty <= minStockLimit

    fun toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "partName" to partName,
        "category" to category,
        "stockQty" to stockQty,
        "minStockLimit" to minStockLimit,
        "unit" to unit,
        "unitPrice" to unitPrice,
        "rackLocation" to rackLocation,
        "barcode" to barcode,
        "updatedAt" to updatedAt
    )

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): SparepartEntity = SparepartEntity(
            id = (map["id"] as? String) ?: "",
            partName = (map["partName"] as? String) ?: "",
            category = (map["category"] as? String) ?: "Umum",
            stockQty = (map["stockQty"] as? Number)?.toInt() ?: 0,
            minStockLimit = (map["minStockLimit"] as? Number)?.toInt() ?: 5,
            unit = (map["unit"] as? String) ?: "Pcs",
            unitPrice = (map["unitPrice"] as? Number)?.toDouble() ?: 0.0,
            rackLocation = (map["rackLocation"] as? String) ?: "",
            barcode = (map["barcode"] as? String) ?: "",
            updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
            isSyncNeeded = false
        )
    }
}
