package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.local.entity.BusEntity
import com.example.data.local.entity.MechanicEntity
import com.example.data.local.entity.PartUsageEntity
import com.example.data.local.entity.ServiceOrderEntity
import com.example.data.local.entity.SparepartEntity
import com.example.data.model.SyncStats
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class WorkshopRepository(private val context: Context) {

    private val database: AppDatabase = AppDatabase.getInstance(context)
    private val busDao = database.busDao()
    private val sparepartDao = database.sparepartDao()
    private val serviceOrderDao = database.serviceOrderDao()
    private val partUsageDao = database.partUsageDao()
    private val mechanicDao = database.mechanicDao()

    private val prefs: SharedPreferences =
        context.getSharedPreferences("bengkel_bus_sync_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "WorkshopRepository"
        private const val PREF_LAST_SYNC_TIME = "last_sync_timestamp"

        // Firestore Collections
        const val COLL_BUSES = "buses"
        const val COLL_SPAREPARTS = "spareparts"
        const val COLL_SERVICE_ORDERS = "service_orders"
        const val COLL_PART_USAGES = "part_usages"
        const val COLL_MECHANICS = "mechanics"
    }

    private fun getFirestore(): FirebaseFirestore? {
        return try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "Firebase initialization skipped or pending configuration: ${e.message}")
            null
        }
    }

    fun isNetworkAvailable(): Boolean {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return false
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun getLastSyncTime(): Long {
        return prefs.getLong(PREF_LAST_SYNC_TIME, 0L)
    }

    private fun setLastSyncTime(timestamp: Long) {
        prefs.edit().putLong(PREF_LAST_SYNC_TIME, timestamp).apply()
    }

    // ==========================================
    // ROOM LOCAL QUERIES (100% Offline-First)
    // ==========================================

    fun getAllBuses(): Flow<List<BusEntity>> = busDao.getAllBuses()
    fun getBusCount(): Flow<Int> = busDao.getBusCount()
    fun getReadyBusCount(): Flow<Int> = busDao.getReadyBusCount()
    fun getMaintenanceBusCount(): Flow<Int> = busDao.getMaintenanceBusCount()

    suspend fun saveBus(bus: BusEntity) = withContext(Dispatchers.IO) {
        val updated = bus.copy(
            updatedAt = System.currentTimeMillis(),
            isSyncNeeded = true
        )
        busDao.insertBus(updated)
    }

    suspend fun deleteBus(id: String) = withContext(Dispatchers.IO) {
        busDao.deleteBus(id)
    }

    fun getAllSpareparts(): Flow<List<SparepartEntity>> = sparepartDao.getAllSpareparts()
    fun getLowStockSpareparts(): Flow<List<SparepartEntity>> = sparepartDao.getLowStockSpareparts()
    fun getLowStockCount(): Flow<Int> = sparepartDao.getLowStockCount()

    suspend fun saveSparepart(part: SparepartEntity) = withContext(Dispatchers.IO) {
        val updated = part.copy(
            updatedAt = System.currentTimeMillis(),
            isSyncNeeded = true
        )
        sparepartDao.insertSparepart(updated)
    }

    suspend fun deleteSparepart(id: String) = withContext(Dispatchers.IO) {
        sparepartDao.deleteSparepart(id)
    }

    fun getAllServiceOrders(): Flow<List<ServiceOrderEntity>> = serviceOrderDao.getAllServiceOrders()
    fun getActiveServiceOrders(): Flow<List<ServiceOrderEntity>> = serviceOrderDao.getActiveServiceOrders()
    fun getActiveOrdersCount(): Flow<Int> = serviceOrderDao.getActiveServiceOrdersCount()

    suspend fun saveServiceOrder(order: ServiceOrderEntity) = withContext(Dispatchers.IO) {
        val updated = order.copy(
            updatedAt = System.currentTimeMillis(),
            isSyncNeeded = true
        )
        serviceOrderDao.insertServiceOrder(updated)
    }

    suspend fun completeServiceOrder(orderId: String, notes: String) = withContext(Dispatchers.IO) {
        val existing = serviceOrderDao.getServiceOrderById(orderId) ?: return@withContext
        val updated = existing.copy(
            status = "COMPLETED",
            completionDate = System.currentTimeMillis(),
            mechanicNotes = if (notes.isNotBlank()) notes else existing.mechanicNotes,
            updatedAt = System.currentTimeMillis(),
            isSyncNeeded = true
        )
        serviceOrderDao.updateServiceOrder(updated)

        // Also update bus status to READY
        val bus = busDao.getBusById(updated.busId)
        if (bus != null) {
            busDao.updateBus(
                bus.copy(
                    status = "READY",
                    updatedAt = System.currentTimeMillis(),
                    isSyncNeeded = true
                )
            )
        }
    }

    fun getUsagesByOrderId(orderId: String): Flow<List<PartUsageEntity>> =
        partUsageDao.getUsagesByOrderId(orderId)

    suspend fun addPartUsage(
        serviceOrderId: String,
        sparepartId: String,
        quantity: Int
    ) = withContext(Dispatchers.IO) {
        val part = sparepartDao.getSparepartById(sparepartId) ?: return@withContext
        val usageId = "USG-${System.currentTimeMillis().toString().takeLast(6)}"
        val unitPrice = part.unitPrice
        val subtotal = unitPrice * quantity

        val usage = PartUsageEntity(
            id = usageId,
            serviceOrderId = serviceOrderId,
            sparepartId = sparepartId,
            partName = part.partName,
            quantity = quantity,
            unitPrice = unitPrice,
            subtotal = subtotal,
            updatedAt = System.currentTimeMillis(),
            isSyncNeeded = true
        )
        partUsageDao.insertPartUsage(usage)

        // Deduct stock in Room
        sparepartDao.deductStock(sparepartId, quantity)

        // Update totalPartsCost in ServiceOrder
        val order = serviceOrderDao.getServiceOrderById(serviceOrderId)
        if (order != null) {
            val newTotalParts = order.totalPartsCost + subtotal
            serviceOrderDao.updateServiceOrder(
                order.copy(
                    totalPartsCost = newTotalParts,
                    updatedAt = System.currentTimeMillis(),
                    isSyncNeeded = true
                )
            )
        }
    }

    fun getAllMechanics(): Flow<List<MechanicEntity>> = mechanicDao.getAllMechanics()
    fun getActiveMechanics(): Flow<List<MechanicEntity>> = mechanicDao.getActiveMechanics()

    suspend fun saveMechanic(mechanic: MechanicEntity) = withContext(Dispatchers.IO) {
        val updated = mechanic.copy(
            updatedAt = System.currentTimeMillis(),
            isSyncNeeded = true
        )
        mechanicDao.insertMechanic(updated)
    }

    // ==========================================
    // SYNC STATS
    // ==========================================

    suspend fun getSyncStats(): SyncStats = withContext(Dispatchers.IO) {
        val unsyncedBuses = busDao.getUnsyncedBuses().size
        val unsyncedParts = sparepartDao.getUnsyncedSpareparts().size
        val unsyncedOrders = serviceOrderDao.getUnsyncedServiceOrders().size
        val unsyncedUsages = partUsageDao.getUnsyncedPartUsages().size
        val lastSync = getLastSyncTime().takeIf { it > 0 }
        SyncStats(
            unsyncedBusesCount = unsyncedBuses,
            unsyncedPartsCount = unsyncedParts,
            unsyncedOrdersCount = unsyncedOrders,
            unsyncedUsagesCount = unsyncedUsages,
            lastSyncTime = lastSync
        )
    }

    // =========================================================================
    // CLOUD SYNC: OFFLINE-FIRST + SPARK PLAN OPTIMIZATIONS
    // 1. syncDataToCloud(): ONLY upload dirty/unsynced records (Batched Writes)
    // 2. fetchDataFromCloud(): ONLY download records where updatedAt > lastSync
    // =========================================================================

    /**
     * Uploads local un-synced data to Cloud Firestore using Batched Writes.
     * Respects Firebase Spark Plan: only writes records that actually changed.
     */
    suspend fun syncDataToCloud(): Result<Int> = withContext(Dispatchers.IO) {
        try {
            if (!isNetworkAvailable()) {
                return@withContext Result.failure(Exception("Tidak ada koneksi internet (Offline Mode)"))
            }

            val firestore = getFirestore()
                ?: return@withContext Result.failure(Exception("Firebase Firestore belum dikonfigurasi"))

            // Fetch unsynced items from Room
            val unsyncedBuses = busDao.getUnsyncedBuses()
            val unsyncedParts = sparepartDao.getUnsyncedSpareparts()
            val unsyncedOrders = serviceOrderDao.getUnsyncedServiceOrders()
            val unsyncedUsages = partUsageDao.getUnsyncedPartUsages()
            val unsyncedMechanics = mechanicDao.getUnsyncedMechanics()

            val totalToUpload = unsyncedBuses.size + unsyncedParts.size +
                    unsyncedOrders.size + unsyncedUsages.size + unsyncedMechanics.size

            if (totalToUpload == 0) {
                return@withContext Result.success(0)
            }

            // Use Firestore Batched Write for atomic, quota-friendly uploads
            val batch = firestore.batch()

            unsyncedBuses.forEach { bus ->
                val docRef = firestore.collection(COLL_BUSES).document(bus.id)
                batch.set(docRef, bus.toFirestoreMap(), SetOptions.merge())
            }

            unsyncedParts.forEach { part ->
                val docRef = firestore.collection(COLL_SPAREPARTS).document(part.id)
                batch.set(docRef, part.toFirestoreMap(), SetOptions.merge())
            }

            unsyncedOrders.forEach { order ->
                val docRef = firestore.collection(COLL_SERVICE_ORDERS).document(order.id)
                batch.set(docRef, order.toFirestoreMap(), SetOptions.merge())
            }

            unsyncedUsages.forEach { usage ->
                val docRef = firestore.collection(COLL_PART_USAGES).document(usage.id)
                batch.set(docRef, usage.toFirestoreMap(), SetOptions.merge())
            }

            unsyncedMechanics.forEach { mech ->
                val docRef = firestore.collection(COLL_MECHANICS).document(mech.id)
                batch.set(docRef, mech.toFirestoreMap(), SetOptions.merge())
            }

            // Commit batch to Firestore
            batch.commit().await()

            // Update Room locally: mark items as synced
            if (unsyncedBuses.isNotEmpty()) busDao.markAsSynced(unsyncedBuses.map { it.id })
            if (unsyncedParts.isNotEmpty()) sparepartDao.markAsSynced(unsyncedParts.map { it.id })
            if (unsyncedOrders.isNotEmpty()) serviceOrderDao.markAsSynced(unsyncedOrders.map { it.id })
            if (unsyncedUsages.isNotEmpty()) partUsageDao.markAsSynced(unsyncedUsages.map { it.id })
            if (unsyncedMechanics.isNotEmpty()) mechanicDao.markAsSynced(unsyncedMechanics.map { it.id })

            Log.i(TAG, "Successfully synced $totalToUpload entities to Firestore")
            Result.success(totalToUpload)
        } catch (e: Exception) {
            Log.e(TAG, "Error syncing data to cloud: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches updated data from Firestore using Delta Queries (whereGreaterThan("updatedAt", lastSyncTimestamp)).
     * Respects Firebase Spark Plan (50k reads limit): only reads documents updated since last sync!
     */
    suspend fun fetchDataFromCloud(): Result<Int> = withContext(Dispatchers.IO) {
        try {
            if (!isNetworkAvailable()) {
                return@withContext Result.failure(Exception("Tidak ada koneksi internet (Offline Mode)"))
            }

            val firestore = getFirestore()
                ?: return@withContext Result.failure(Exception("Firebase Firestore belum dikonfigurasi"))

            val lastSync = getLastSyncTime()
            var downloadedCount = 0

            // 1. Fetch Buses delta
            val busQuery = if (lastSync > 0) {
                firestore.collection(COLL_BUSES).whereGreaterThan("updatedAt", lastSync)
            } else {
                firestore.collection(COLL_BUSES)
            }
            val busSnapshot = busQuery.get().await()
            val remoteBuses = busSnapshot.documents.mapNotNull { doc ->
                doc.data?.let { BusEntity.fromFirestoreMap(it) }
            }
            if (remoteBuses.isNotEmpty()) {
                busDao.insertBuses(remoteBuses)
                downloadedCount += remoteBuses.size
            }

            // 2. Fetch Spareparts delta
            val partQuery = if (lastSync > 0) {
                firestore.collection(COLL_SPAREPARTS).whereGreaterThan("updatedAt", lastSync)
            } else {
                firestore.collection(COLL_SPAREPARTS)
            }
            val partSnapshot = partQuery.get().await()
            val remoteParts = partSnapshot.documents.mapNotNull { doc ->
                doc.data?.let { SparepartEntity.fromFirestoreMap(it) }
            }
            if (remoteParts.isNotEmpty()) {
                sparepartDao.insertSpareparts(remoteParts)
                downloadedCount += remoteParts.size
            }

            // 3. Fetch Service Orders delta
            val orderQuery = if (lastSync > 0) {
                firestore.collection(COLL_SERVICE_ORDERS).whereGreaterThan("updatedAt", lastSync)
            } else {
                firestore.collection(COLL_SERVICE_ORDERS)
            }
            val orderSnapshot = orderQuery.get().await()
            val remoteOrders = orderSnapshot.documents.mapNotNull { doc ->
                doc.data?.let { ServiceOrderEntity.fromFirestoreMap(it) }
            }
            if (remoteOrders.isNotEmpty()) {
                serviceOrderDao.insertServiceOrders(remoteOrders)
                downloadedCount += remoteOrders.size
            }

            // 4. Fetch Part Usages delta
            val usageQuery = if (lastSync > 0) {
                firestore.collection(COLL_PART_USAGES).whereGreaterThan("updatedAt", lastSync)
            } else {
                firestore.collection(COLL_PART_USAGES)
            }
            val usageSnapshot = usageQuery.get().await()
            val remoteUsages = usageSnapshot.documents.mapNotNull { doc ->
                doc.data?.let { PartUsageEntity.fromFirestoreMap(it) }
            }
            if (remoteUsages.isNotEmpty()) {
                partUsageDao.insertPartUsages(remoteUsages)
                downloadedCount += remoteUsages.size
            }

            // 5. Fetch Mechanics delta
            val mechQuery = if (lastSync > 0) {
                firestore.collection(COLL_MECHANICS).whereGreaterThan("updatedAt", lastSync)
            } else {
                firestore.collection(COLL_MECHANICS)
            }
            val mechSnapshot = mechQuery.get().await()
            val remoteMechs = mechSnapshot.documents.mapNotNull { doc ->
                doc.data?.let { MechanicEntity.fromFirestoreMap(it) }
            }
            if (remoteMechs.isNotEmpty()) {
                mechanicDao.insertMechanics(remoteMechs)
                downloadedCount += remoteMechs.size
            }

            // Update last sync time
            setLastSyncTime(System.currentTimeMillis())

            Log.i(TAG, "Successfully fetched $downloadedCount updated entities from Firestore")
            Result.success(downloadedCount)
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching data from cloud: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Complete 2-way sync:
     * 1. Push local changes to cloud
     * 2. Pull remote changes to local Room
     */
    suspend fun syncAll(): Result<Pair<Int, Int>> = withContext(Dispatchers.IO) {
        val uploadResult = syncDataToCloud()
        if (uploadResult.isFailure) {
            return@withContext Result.failure(uploadResult.exceptionOrNull() ?: Exception("Upload gagal"))
        }

        val fetchResult = fetchDataFromCloud()
        if (fetchResult.isFailure) {
            return@withContext Result.failure(fetchResult.exceptionOrNull() ?: Exception("Download gagal"))
        }

        val uploaded = uploadResult.getOrDefault(0)
        val downloaded = fetchResult.getOrDefault(0)
        Result.success(Pair(uploaded, downloaded))
    }
}

/**
 * Lightweight await extension for Play Services Task to avoid missing external dependencies.
 */
suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { result ->
        if (cont.isActive) cont.resume(result)
    }
    addOnFailureListener { exception ->
        if (cont.isActive) cont.resumeWithException(exception)
    }
    addOnCanceledListener {
        if (cont.isActive) cont.cancel()
    }
}
