package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "buses")
data class BusEntity(
    @PrimaryKey
    val id: String, // e.g. "BUS-01" or UUID
    val plateNumber: String, // e.g. "B 7123 TGA"
    val fleetNumber: String, // e.g. "BUS-042"
    val busModel: String, // e.g. "Jetbus 3+ HDD / Mercedes-Benz OH 1626"
    val capacity: Int = 50,
    val mileageKm: Int = 0, // Odometer
    val status: String = "READY", // "READY" (Siap Jalan), "MAINTENANCE" (Servis/Perbaikan), "STANDBY"
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
    val isSyncNeeded: Boolean = true
) {
    fun toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "plateNumber" to plateNumber,
        "fleetNumber" to fleetNumber,
        "busModel" to busModel,
        "capacity" to capacity,
        "mileageKm" to mileageKm,
        "status" to status,
        "notes" to notes,
        "updatedAt" to updatedAt
    )

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): BusEntity = BusEntity(
            id = (map["id"] as? String) ?: "",
            plateNumber = (map["plateNumber"] as? String) ?: "",
            fleetNumber = (map["fleetNumber"] as? String) ?: "",
            busModel = (map["busModel"] as? String) ?: "",
            capacity = (map["capacity"] as? Number)?.toInt() ?: 50,
            mileageKm = (map["mileageKm"] as? Number)?.toInt() ?: 0,
            status = (map["status"] as? String) ?: "READY",
            notes = (map["notes"] as? String) ?: "",
            updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
            isSyncNeeded = false
        )
    }
}
