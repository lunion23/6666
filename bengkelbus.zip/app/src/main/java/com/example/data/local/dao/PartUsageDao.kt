package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.PartUsageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PartUsageDao {
    @Query("SELECT * FROM part_usages WHERE serviceOrderId = :serviceOrderId")
    fun getUsagesByOrderId(serviceOrderId: String): Flow<List<PartUsageEntity>>

    @Query("SELECT * FROM part_usages")
    fun getAllPartUsages(): Flow<List<PartUsageEntity>>

    @Query("SELECT * FROM part_usages WHERE isSyncNeeded = 1")
    suspend fun getUnsyncedPartUsages(): List<PartUsageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPartUsage(usage: PartUsageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPartUsages(usages: List<PartUsageEntity>)

    @Query("UPDATE part_usages SET isSyncNeeded = 0 WHERE id IN (:ids)")
    suspend fun markAsSynced(ids: List<String>)

    @Query("DELETE FROM part_usages WHERE id = :id")
    suspend fun deletePartUsage(id: String)
}
