package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BusBlue80 = Color(0xFF90CAF9)
val BusAmber80 = Color(0xFFFFD54F)
val BusTeal80 = Color(0xFF80CBC4)

val BusBlue40 = Color(0xFF0D47A1)
val BusAmber40 = Color(0xFFE65100)
val BusTeal40 = Color(0xFF00695C)

val WorkshopDarkBg = Color(0xFF121418)
val WorkshopDarkSurface = Color(0xFF1E222B)

