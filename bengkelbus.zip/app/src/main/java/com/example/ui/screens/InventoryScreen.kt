package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.SparepartEntity
import com.example.ui.components.formatRupiah
import com.example.ui.viewmodel.WorkshopViewModel

@Composable
fun InventoryScreen(
    viewModel: WorkshopViewModel,
    modifier: Modifier = Modifier
) {
    val spareparts by viewModel.spareparts.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("ALL") }
    var showAddDialog by remember { mutableStateOf(false) }
    var partToEdit by remember { mutableStateOf<SparepartEntity?>(null) }
    var partToDelete by remember { mutableStateOf<SparepartEntity?>(null) }

    val filteredParts = remember(spareparts, searchQuery, selectedCategory) {
        spareparts.filter { part ->
            val matchSearch = part.partName.contains(searchQuery, ignoreCase = true) ||
                    part.id.contains(searchQuery, ignoreCase = true) ||
                    part.rackLocation.contains(searchQuery, ignoreCase = true)
            val matchCat = when (selectedCategory) {
                "LOW_STOCK" -> part.isLowStock
                "ALL" -> true
                else -> part.category.equals(selectedCategory, ignoreCase = true)
            }
            matchSearch && matchCat
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    partToEdit = null
                    showAddDialog = true
                },
                modifier = Modifier.testTag("fab_add_sparepart"),
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Tambah Sparepart")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Inventaris Sparepart Bengkel",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Kelola stok sparepart offline di Room dengan sinkronisasi Firebase Firestore",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Cari nama part, kode SKU, atau rak...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Cari") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = selectedCategory == "ALL",
                        onClick = { selectedCategory = "ALL" },
                        label = { Text("Semua (${spareparts.size})") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == "LOW_STOCK",
                        onClick = { selectedCategory = "LOW_STOCK" },
                        label = { Text("Stok Menipis (${spareparts.count { it.isLowStock }})") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == "Mesin",
                        onClick = { selectedCategory = "Mesin" },
                        label = { Text("Mesin") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == "Pengereman",
                        onClick = { selectedCategory = "Pengereman" },
                        label = { Text("Pengereman") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == "Oli & Fluida",
                        onClick = { selectedCategory = "Oli & Fluida" },
                        label = { Text("Oli & Fluida") }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredParts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Tidak ada sparepart yang sesuai pencarian.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(filteredParts, key = { it.id }) { part ->
                        SparepartCardItem(
                            part = part,
                            onEdit = {
                                partToEdit = part
                                showAddDialog = true
                            },
                            onDelete = {
                                partToDelete = part
                            }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(72.dp))
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        SparepartFormDialog(
            initialPart = partToEdit,
            onDismiss = {
                showAddDialog = false
                partToEdit = null
            },
            onSave = { id, name, cat, stock, minLimit, unit, price, rack, barcode ->
                viewModel.addOrUpdateSparepart(
                    id = id,
                    name = name,
                    category = cat,
                    stockQty = stock,
                    minLimit = minLimit,
                    unit = unit,
                    unitPrice = price,
                    rackLocation = rack,
                    barcode = barcode
                )
                showAddDialog = false
                partToEdit = null
            }
        )
    }

    partToDelete?.let { part ->
        AlertDialog(
            onDismissRequest = { partToDelete = null },
            title = { Text("Hapus Sparepart?") },
            text = { Text("Apakah Anda yakin ingin menghapus ${part.partName} (${part.id}) dari database bengkel?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteSparepart(part.id)
                        partToDelete = null
                    }
                ) {
                    Text("Hapus")
                }
            },
            dismissButton = {
                TextButton(onClick = { partToDelete = null }) {
                    Text("Batal")
                }
            }
        )
    }
}

@Composable
fun SparepartCardItem(
    part: SparepartEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isLow = part.isLowStock
    val stockBg = if (isLow) Color(0xFFFFEBEE) else Color(0xFFE8F5E9)
    val stockColor = if (isLow) Color(0xFFC62828) else Color(0xFF2E7D32)

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = part.id,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = part.category,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = stockBg
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            if (isLow) {
                                Icon(
                                    Icons.Default.Warning,
                                    contentDescription = "Stok Menipis",
                                    tint = stockColor,
                                    modifier = Modifier.padding(end = 4.dp)
                                )
                            }
                            Text(
                                text = "Stok: ${part.stockQty} ${part.unit}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = stockColor
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = if (part.isSyncNeeded) Icons.Default.CloudQueue else Icons.Default.CloudDone,
                        contentDescription = if (part.isSyncNeeded) "Perlu Sync" else "Tersinkron",
                        tint = if (part.isSyncNeeded) Color(0xFFE65100) else Color(0xFF2E7D32),
                        modifier = Modifier.padding(2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = part.partName,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Harga: ${formatRupiah(part.unitPrice)} / ${part.unit}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Lokasi: ${part.rackLocation} • Min Limit: ${part.minStockLimit} ${part.unit}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Part")
                    }
                    IconButton(onClick = onDelete) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Hapus Part",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SparepartFormDialog(
    initialPart: SparepartEntity?,
    onDismiss: () -> Unit,
    onSave: (id: String, name: String, cat: String, stock: Int, minLimit: Int, unit: String, price: Double, rack: String, barcode: String) -> Unit
) {
    var name by remember { mutableStateOf(initialPart?.partName ?: "") }
    var category by remember { mutableStateOf(initialPart?.category ?: "Mesin") }
    var stockText by remember { mutableStateOf((initialPart?.stockQty ?: 10).toString()) }
    var minLimitText by remember { mutableStateOf((initialPart?.minStockLimit ?: 5).toString()) }
    var unit by remember { mutableStateOf(initialPart?.unit ?: "Pcs") }
    var priceText by remember { mutableStateOf((initialPart?.unitPrice?.toLong() ?: 150000L).toString()) }
    var rackLocation by remember { mutableStateOf(initialPart?.rackLocation ?: "Rak A-01") }
    var barcode by remember { mutableStateOf(initialPart?.barcode ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialPart == null) "Tambah Sparepart Baru" else "Edit Sparepart") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Sparepart") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Kategori") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Satuan (Pcs/Ltr/Set)") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = stockText,
                        onValueChange = { stockText = it },
                        label = { Text("Jumlah Stok") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minLimitText,
                        onValueChange = { minLimitText = it },
                        label = { Text("Batas Min") },
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("Harga Satuan (Rp)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = rackLocation,
                    onValueChange = { rackLocation = it },
                    label = { Text("Lokasi Rak / Gudang") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(
                            initialPart?.id ?: "",
                            name,
                            category,
                            stockText.toIntOrNull() ?: 0,
                            minLimitText.toIntOrNull() ?: 5,
                            unit,
                            priceText.toDoubleOrNull() ?: 0.0,
                            rackLocation,
                            barcode
                        )
                    }
                },
                enabled = name.isNotBlank()
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
