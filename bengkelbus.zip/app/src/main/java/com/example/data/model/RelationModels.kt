package com.example.data.model

import com.example.data.local.entity.PartUsageEntity
import com.example.data.local.entity.ServiceOrderEntity

data class ServiceOrderDetail(
    val order: ServiceOrderEntity,
    val partsUsed: List<PartUsageEntity> = emptyList()
)

sealed class SyncState {
    data object Idle : SyncState()
    data class Syncing(val message: String = "Menyinkronkan data...") : SyncState()
    data class Success(val summary: String, val timestamp: Long = System.currentTimeMillis()) : SyncState()
    data class Error(val errorMessage: String, val timestamp: Long = System.currentTimeMillis()) : SyncState()
}

data class SyncStats(
    val unsyncedBusesCount: Int = 0,
    val unsyncedPartsCount: Int = 0,
    val unsyncedOrdersCount: Int = 0,
    val unsyncedUsagesCount: Int = 0,
    val lastSyncTime: Long? = null
) {
    val totalPendingChanges: Int
        get() = unsyncedBusesCount + unsyncedPartsCount + unsyncedOrdersCount + unsyncedUsagesCount
}
