package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.BusEntity
import com.example.ui.viewmodel.WorkshopViewModel

@Composable
fun BusScreen(
    viewModel: WorkshopViewModel,
    modifier: Modifier = Modifier
) {
    val buses by viewModel.buses.collectAsState()
    var selectedFilter by remember { mutableStateOf("ALL") }
    var showAddDialog by remember { mutableStateOf(false) }
    var busToEdit by remember { mutableStateOf<BusEntity?>(null) }
    var busToDelete by remember { mutableStateOf<BusEntity?>(null) }

    val filteredBuses = remember(buses, selectedFilter) {
        when (selectedFilter) {
            "READY" -> buses.filter { it.status == "READY" }
            "MAINTENANCE" -> buses.filter { it.status == "MAINTENANCE" }
            "STANDBY" -> buses.filter { it.status == "STANDBY" }
            else -> buses
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    busToEdit = null
                    showAddDialog = true
                },
                modifier = Modifier.testTag("fab_add_bus"),
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Tambah Bus")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Manajemen Armada Bus",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Data armada tersimpan di Room dan otomatis disinkronkan ke Firestore",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Filter Chips
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = selectedFilter == "ALL",
                        onClick = { selectedFilter = "ALL" },
                        label = { Text("Semua (${buses.size})") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedFilter == "READY",
                        onClick = { selectedFilter = "READY" },
                        label = { Text("Siap Jalan (${buses.count { it.status == "READY" }})") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedFilter == "MAINTENANCE",
                        onClick = { selectedFilter = "MAINTENANCE" },
                        label = { Text("Perbaikan (${buses.count { it.status == "MAINTENANCE" }})") }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredBuses.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Belum ada armada untuk kategori ini.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(filteredBuses, key = { it.id }) { bus ->
                        BusCardItem(
                            bus = bus,
                            onEdit = {
                                busToEdit = bus
                                showAddDialog = true
                            },
                            onDelete = {
                                busToDelete = bus
                            }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(72.dp))
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        BusFormDialog(
            initialBus = busToEdit,
            onDismiss = {
                showAddDialog = false
                busToEdit = null
            },
            onSave = { id, plate, fleet, model, capacity, km, status, notes ->
                viewModel.addOrUpdateBus(
                    id = id,
                    plateNumber = plate,
                    fleetNumber = fleet,
                    busModel = model,
                    capacity = capacity,
                    mileageKm = km,
                    status = status,
                    notes = notes
                )
                showAddDialog = false
                busToEdit = null
            }
        )
    }

    busToDelete?.let { bus ->
        AlertDialog(
            onDismissRequest = { busToDelete = null },
            title = { Text("Hapus Armada?") },
            text = { Text("Apakah Anda yakin ingin menghapus bus ${bus.fleetNumber} (${bus.plateNumber}) dari database?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteBus(bus.id)
                        busToDelete = null
                    }
                ) {
                    Text("Hapus")
                }
            },
            dismissButton = {
                TextButton(onClick = { busToDelete = null }) {
                    Text("Batal")
                }
            }
        )
    }
}

@Composable
fun BusCardItem(
    bus: BusEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val statusBg = when (bus.status) {
        "READY" -> Color(0xFFE8F5E9)
        "MAINTENANCE" -> Color(0xFFFFF3E0)
        else -> Color(0xFFECEFF1)
    }
    val statusColor = when (bus.status) {
        "READY" -> Color(0xFF2E7D32)
        "MAINTENANCE" -> Color(0xFFE65100)
        else -> Color(0xFF455A64)
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.padding(end = 10.dp)
                    ) {
                        Text(
                            text = bus.fleetNumber,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Text(
                        text = bus.plateNumber,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = statusBg
                    ) {
                        Text(
                            text = if (bus.status == "READY") "SIAP JALAN" else "PERBAIKAN",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = statusColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = if (bus.isSyncNeeded) Icons.Default.CloudQueue else Icons.Default.CloudDone,
                        contentDescription = if (bus.isSyncNeeded) "Perlu Sync" else "Tersinkron Cloud",
                        tint = if (bus.isSyncNeeded) Color(0xFFE65100) else Color(0xFF2E7D32),
                        modifier = Modifier.padding(2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = bus.busModel,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = "Odometer",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    Text(
                        text = "%,d KM".format(bus.mileageKm),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "${bus.capacity} Kursi",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Bus")
                    }
                    IconButton(onClick = onDelete) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Hapus Bus",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            if (bus.notes.isNotBlank()) {
                Text(
                    text = "Catatan: ${bus.notes}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun BusFormDialog(
    initialBus: BusEntity?,
    onDismiss: () -> Unit,
    onSave: (id: String, plate: String, fleet: String, model: String, capacity: Int, km: Int, status: String, notes: String) -> Unit
) {
    var plateNumber by remember { mutableStateOf(initialBus?.plateNumber ?: "") }
    var fleetNumber by remember { mutableStateOf(initialBus?.fleetNumber ?: "") }
    var busModel by remember { mutableStateOf(initialBus?.busModel ?: "") }
    var capacityText by remember { mutableStateOf((initialBus?.capacity ?: 50).toString()) }
    var mileageText by remember { mutableStateOf((initialBus?.mileageKm ?: 0).toString()) }
    var status by remember { mutableStateOf(initialBus?.status ?: "READY") }
    var notes by remember { mutableStateOf(initialBus?.notes ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialBus == null) "Tambah Armada Bus" else "Edit Armada Bus") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = fleetNumber,
                    onValueChange = { fleetNumber = it },
                    label = { Text("Nomor Lambung (cth: ARM-05)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = plateNumber,
                    onValueChange = { plateNumber = it },
                    label = { Text("Nomor Polisi (cth: B 7123 TGA)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = busModel,
                    onValueChange = { busModel = it },
                    label = { Text("Model / Karoseri / Chasis") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = mileageText,
                        onValueChange = { mileageText = it },
                        label = { Text("Odometer KM") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = capacityText,
                        onValueChange = { capacityText = it },
                        label = { Text("Kapasitas") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = status == "READY",
                        onClick = { status = "READY" },
                        label = { Text("Siap Jalan") }
                    )
                    FilterChip(
                        selected = status == "MAINTENANCE",
                        onClick = { status = "MAINTENANCE" },
                        label = { Text("Perbaikan") }
                    )
                }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Catatan Armada") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (plateNumber.isNotBlank() && fleetNumber.isNotBlank()) {
                        onSave(
                            initialBus?.id ?: "",
                            plateNumber,
                            fleetNumber,
                            busModel,
                            capacityText.toIntOrNull() ?: 50,
                            mileageText.toIntOrNull() ?: 0,
                            status,
                            notes
                        )
                    }
                },
                enabled = plateNumber.isNotBlank() && fleetNumber.isNotBlank()
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
