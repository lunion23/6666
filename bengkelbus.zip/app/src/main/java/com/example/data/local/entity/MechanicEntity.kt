package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mechanics")
data class MechanicEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val phone: String = "",
    val specialty: String = "Mesin", // "Mesin", "Kelistrikan", "Kaki-Kaki & Rem", "AC & Body"
    val status: String = "ACTIVE", // "ACTIVE", "LEAVE", "INACTIVE"
    val updatedAt: Long = System.currentTimeMillis(),
    val isSyncNeeded: Boolean = true
) {
    fun toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "name" to name,
        "phone" to phone,
        "specialty" to specialty,
        "status" to status,
        "updatedAt" to updatedAt
    )

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): MechanicEntity = MechanicEntity(
            id = (map["id"] as? String) ?: "",
            name = (map["name"] as? String) ?: "",
            phone = (map["phone"] as? String) ?: "",
            specialty = (map["specialty"] as? String) ?: "Mesin",
            status = (map["status"] as? String) ?: "ACTIVE",
            updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
            isSyncNeeded = false
        )
    }
}
