package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "service_orders")
data class ServiceOrderEntity(
    @PrimaryKey
    val id: String, // e.g. "SPK-2026-001"
    val busId: String, // Refers to BusEntity.id
    val busPlate: String = "", // Denormalized for display offline
    val mechanicId: String = "",
    val mechanicName: String = "",
    val complaint: String, // Keluhan pengemudi / catatan kerusakan
    val status: String = "PENDING", // "PENDING", "ON_PROGRESS", "COMPLETED", "CANCELLED"
    val entryDate: Long = System.currentTimeMillis(),
    val completionDate: Long? = null,
    val laborCost: Double = 0.0,
    val totalPartsCost: Double = 0.0,
    val mechanicNotes: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
    val isSyncNeeded: Boolean = true
) {
    val totalCost: Double get() = laborCost + totalPartsCost

    fun toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "busId" to busId,
        "busPlate" to busPlate,
        "mechanicId" to mechanicId,
        "mechanicName" to mechanicName,
        "complaint" to complaint,
        "status" to status,
        "entryDate" to entryDate,
        "completionDate" to completionDate,
        "laborCost" to laborCost,
        "totalPartsCost" to totalPartsCost,
        "mechanicNotes" to mechanicNotes,
        "updatedAt" to updatedAt
    )

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): ServiceOrderEntity = ServiceOrderEntity(
            id = (map["id"] as? String) ?: "",
            busId = (map["busId"] as? String) ?: "",
            busPlate = (map["busPlate"] as? String) ?: "",
            mechanicId = (map["mechanicId"] as? String) ?: "",
            mechanicName = (map["mechanicName"] as? String) ?: "",
            complaint = (map["complaint"] as? String) ?: "",
            status = (map["status"] as? String) ?: "PENDING",
            entryDate = (map["entryDate"] as? Number)?.toLong() ?: System.currentTimeMillis(),
            completionDate = (map["completionDate"] as? Number)?.toLong(),
            laborCost = (map["laborCost"] as? Number)?.toDouble() ?: 0.0,
            totalPartsCost = (map["totalPartsCost"] as? Number)?.toDouble() ?: 0.0,
            mechanicNotes = (map["mechanicNotes"] as? String) ?: "",
            updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
            isSyncNeeded = false
        )
    }
}
